Authors: Eemil Jeskanen, Oscar Hjern, Johann Tammen

Distribution:
Task one: Oscar
Task two: Oscar & Johann
Task three: Eemil
Task four: Eemil
Task five: Oscar, Eemil, Johann

We all started working on the different tasks individually. We merged the different tasks together,
had to change the logic of the program a couple of times, which we did together.
In the end we did the final touch-up of the code together.

